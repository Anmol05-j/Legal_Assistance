const express = require("express");
const cors = require("cors");
const axios = require("axios");
const fs = require("fs");
require("dotenv").config();

const app = express();
const port = 3000;

app.use(cors());
app.use(express.json());

// Serve static files (like index.html, script.js, IPCdatabase.json)
app.use(express.static(__dirname + "/public"));

// OpenAI route
app.post("/ask-lawbot", async (req, res) => {
  const userInput = req.body.message;

  try {
    const response = await axios.post(
      "https://api.openai.com/v1/chat/completions",
      {
        model: "gpt-3.5-turbo",
        messages: [{ role: "user", content: userInput }],
        temperature: 0.7
      },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${process.env.OPENAI_API_KEY}`
        }
      }
    );

    const reply = response.data.choices?.[0]?.message?.content || "";
    res.json({ reply });
  } catch (error) {
    console.error("OpenAI Error:", error.response?.data || error.message);
    res.status(500).json({ reply: "LawBot failed to reply. Try again." });
  }
});

// IPC JSON route
app.get("/ipcdata", (req, res) => {
  fs.readFile(__dirname + "/public/IPCdatabase.json", "utf8", (err, data) => {
    if (err) {
      console.error("JSON Read Error:", err);
      return res.status(500).json({ error: "Cannot load IPC data." });
    }
    res.type("application/json").send(data);
  });
});

app.listen(port, () => {
  console.log(`LawBot backend is running at http://localhost:${port}`);
});

document.addEventListener("DOMContentLoaded", () => {
  const searchBtn = document.getElementById("searchBtn");
  const searchInput = document.getElementById("searchInput");

  searchBtn.addEventListener("click", () => {
    const query = searchInput.value.trim();
    const resultBox = document.getElementById("resultBox");

    // IPC Match
    const ipcMatch = query.match(/Section\s+(\d+)\s+IPC/i);
    if (ipcMatch) {
      const sectionNumber = ipcMatch[1];
      const url = `ipc-result.html?section=${sectionNumber}`;
      window.location.href = url;
      return;
    }

    // CrPC Match
    const crpcMatch = query.match(/Section\s+(\d+)\s+(CrPC|Code of Criminal Procedure)/i);
    if (crpcMatch) {
      const sectionNumber = crpcMatch[1];
      const url = `CrPc-result.html?section=${sectionNumber}`;
      window.location.href = url;
      return;
    }

    // ICA Match (Indian Contract Act)
    const icaMatch = query.match(/Section\s+(\d+)\s+(ICA|Indian Contract Act)/i);
    if (icaMatch) {
      const sectionNumber = icaMatch[1];
      const url = `ICA-result.html?section=${sectionNumber}`;
      window.location.href = url;
      return;
    }

    // Motor Vehicles Act Match
    const mvaMatch = query.match(/Section\s+(\d+)\s+(MVA|Motor Vehicle|Motor Vehicles Act)/i);
    if (mvaMatch) {
      const sectionNumber = mvaMatch[1];
      const url = `motorvehicles.html?section=${sectionNumber}`;
      window.location.href = url;
      return;
    }

    // Maxims Match (Simple heuristic: assume 3+ words and no numbers)
    if (/^[a-zA-Z\s]+$/.test(query) && query.split(" ").length >= 2) {
      const url = `maxims.html?maxim=${encodeURIComponent(query)}`;
      window.location.href = url;
      return;
    }

    // If none matched
    resultBox.innerText = "❌ Please enter a valid query like: Section 302 IPC, Section 125 CrPC, Section 114 ICA, Section 3 MVA, or a valid Legal Maxim like Audi alteram partem.";
  });
});



document.addEventListener("DOMContentLoaded", () => {
  const params = new URLSearchParams(window.location.search);
  const sectionNumber = params.get("section");

  fetch("ICAdatabase.json")
    .then((response) => response.json())
    .then((data) => {
      const sectionData = data.sections.find(
        (sec) => String(sec.section) === sectionNumber
      );

      if (!sectionData) {
        document.getElementById("sectionTitle").textContent = "❌ Section not found";
        return;
      }

      // Fill basic info
      document.getElementById("sectionTitle").textContent = `${sectionData.section}. ${sectionData.title}`;
      document.getElementById("sectionText").textContent = sectionData.text || "";
      document.getElementById("illustration").textContent = sectionData.illustration || "";
      document.getElementById("explanation").textContent = sectionData.explanation || "";
      document.getElementById("summary").textContent = sectionData.summary || "";

      // Normalize case_law to always be an array
      let caseLawArray = [];

      if (Array.isArray(sectionData.case_law)) {
        caseLawArray = sectionData.case_law;
      } else if (typeof sectionData.case_law === "object" && sectionData.case_law !== null) {
        caseLawArray = [sectionData.case_law]; // wrap single object
      }

      // Fill case law info (only the first shown)
      const nameElem = document.getElementById("caseName");
      const citationElem = document.getElementById("citation");
      const noteElem = document.getElementById("note");

      if (caseLawArray.length > 0) {
        const caseLaw = caseLawArray[0];

        nameElem.textContent = caseLaw.name || "N/A";
        nameElem.href = caseLaw.link || "#";
        citationElem.textContent = caseLaw.citation || "N/A";
        noteElem.textContent = caseLaw.note || "N/A";
      } else {
        nameElem.textContent = "N/A";
        nameElem.removeAttribute("href");
        citationElem.textContent = "N/A";
        noteElem.textContent = "N/A";
      }
    })
    .catch((error) => {
      console.error("Error loading ICA data:", error);
      document.getElementById("sectionTitle").textContent = "❌ Error loading data";
    });
});


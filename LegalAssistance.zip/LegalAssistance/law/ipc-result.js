document.addEventListener("DOMContentLoaded", () => {
  const params = new URLSearchParams(window.location.search);

  const section = params.get("section");

  if (!section) {
    document.getElementById("sectionTitle").innerText = "❌ Error loading section.";
    return;
  }

  fetch("IPCDatabase.json")
    .then(response => {
      if (!response.ok) throw new Error("❌ Failed to load IPCDatabase.json");
      return response.json();
    })
    .then(data => {
      const sectionData = data.sections.find(item =>
        item.section.toString() === section
      );

      if (!sectionData) throw new Error("❌ Section not found in database");

      // ✅ Set the title and text from JSON
      document.getElementById("sectionTitle").innerText = `Section ${section}: ${sectionData.title}`;
      document.getElementById("sectionText").innerText = sectionData.text;

      // ✅ Set illustration, explanation, summary
      document.getElementById("illustration").innerText = sectionData.illustration || "N/A";
      document.getElementById("explanation").innerText = sectionData.explanation || "N/A";
      document.getElementById("summary").innerText = sectionData.summary || "N/A";

      // ✅ Case Law
      const caseLaw = sectionData.case_law || {};
      const caseNameElement = document.getElementById("caseName");
      const citationElement = document.getElementById("caseCitation");
      const noteElement = document.getElementById("caseNote");

      if (caseLaw.name) {
        const encodedName = encodeURIComponent(caseLaw.name);
        const caseMineURL = `https://www.casemine.com/search?q=${encodedName}`;
        caseNameElement.innerHTML = `<a href="${caseMineURL}" target="_blank">${caseLaw.name}</a>`;
      } else {
        caseNameElement.innerText = "N/A";
      }

      citationElement.innerText = caseLaw.citation || "N/A";
      noteElement.innerText = caseLaw.note || "N/A";
    })
    .catch(error => {
      console.error("IPC JSON load error:", error);
      document.getElementById("sectionTitle").innerText = "❌ Error loading section.";
    });
});

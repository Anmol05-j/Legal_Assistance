document.addEventListener("DOMContentLoaded", () => {
  const params = new URLSearchParams(window.location.search);
  const maximName = params.get("maxim");
  const titleElement = document.getElementById("maximTitle");

  if (!maximName) {
    titleElement.textContent = "❌ No maxim specified.";
    return;
  }

  fetch("maxims.json")
    .then(response => {
      if (!response.ok) throw new Error("❌ Failed to load maxims.json");
      return response.json();
    })
    .then(data => {
      const maximData = data.maxims.find(item =>
        item.maxim.toLowerCase() === maximName.toLowerCase()
      );

      if (!maximData) throw new Error("❌ Maxim not found in database");

      titleElement.textContent = maximData.maxim;
      titleElement.className = "maxim-title"; // ensure styling is kept

      document.getElementById("meaning").textContent = maximData.meaning || "N/A";
      document.getElementById("explanation").textContent = maximData.explanation || "N/A";
      document.getElementById("example").textContent = maximData.example || "N/A";

      const landmarkCaseElement = document.getElementById("landmarkCase");
      if (maximData.landmark_case) {
        const encodedCase = encodeURIComponent(maximData.landmark_case);
        const caseMineURL = `https://www.casemine.com/search?q=${encodedCase}`;
        landmarkCaseElement.innerHTML = `<a href="${caseMineURL}" target="_blank" class="case-link">${maximData.landmark_case}</a>`;
      } else {
        landmarkCaseElement.textContent = "N/A";
      }
    })
    .catch(error => {
      console.error(error);
      titleElement.textContent = "❌ Error loading maxim.";
      titleElement.className = "maxim-title"; // ensure class is kept on error
    });
});

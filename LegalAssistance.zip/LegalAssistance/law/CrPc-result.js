document.addEventListener('DOMContentLoaded', async () => {
  const urlParams = new URLSearchParams(window.location.search);
  const sectionNumber = urlParams.get('section');

  if (!sectionNumber) {
    document.getElementById('sectionTitle').innerText = "No section number provided in the URL.";
    return;
  }

  try {
    const response = await fetch('CrPCDatabase.json');
    const data = await response.json();
    const sectionData = data.sections.find(
      s => s.section === sectionNumber || s.section === Number(sectionNumber)
    );

    if (!sectionData) {
      document.getElementById('sectionTitle').innerText = `Section ${sectionNumber} not found.`;
      return;
    }

    document.getElementById('sectionTitle').innerText = `Section ${sectionData.section} - ${sectionData.title}`;
    document.getElementById('sectionText').innerText = sectionData.text || "—";
    document.getElementById('illustration').innerText = sectionData.illustration || "—";
    document.getElementById('explanation').innerText = sectionData.explanation || "—";

    if (sectionData.case_law && sectionData.case_law.length > 0) {
      const caseLaw = sectionData.case_law[0];
      document.getElementById('caseName').innerText = caseLaw.name || "—";
      document.getElementById('citation').innerText = caseLaw.citation || "—";
      document.getElementById('note').innerText = caseLaw.note || "—";
    } else {
      document.getElementById('caseName').innerText = "—";
      document.getElementById('citation').innerText = "—";
      document.getElementById('note').innerText = "—";
    }

    document.getElementById('summary').innerText = sectionData.summary || "—";
  } catch (error) {
    console.error('Error loading CrPC data:', error);
    document.getElementById('sectionTitle').innerText = "Failed to load section data.";
  }
});

document.addEventListener("DOMContentLoaded", () => {
  const params = new URLSearchParams(window.location.search);
  const section = params.get("section");

  fetch("./motorvehicles.json")
    .then(res => res.json())
    .then(data => {
      const sectionData = data.sections.find(s => s.section == section);

      if (!sectionData) {
        document.getElementById("sectionTitle").textContent = "Section not found";
        return;
      }

      document.getElementById("sectionTitle").textContent = `Section ${sectionData.section}: ${sectionData.title}`;
      document.getElementById("sectionText").textContent = sectionData.text || "N/A";
      document.getElementById("illustration").textContent = sectionData.illustration || "N/A";
      document.getElementById("explanation").textContent = sectionData.explanation || "N/A";
      document.getElementById("summary").textContent = sectionData.summary || "N/A";

      // Case Law
      const caseLaw = sectionData.case_law || {};
      document.getElementById("caseName").textContent = caseLaw.name || "N/A";
      document.getElementById("caseName").href = caseLaw.link || "#";
      document.getElementById("citation").textContent = caseLaw.citation || "N/A";
      document.getElementById("note").textContent = caseLaw.note || "N/A";
    })
    .catch(err => {
      console.error("Error loading data:", err);
      document.getElementById("sectionTitle").textContent = "Error loading section data";
    });
});
